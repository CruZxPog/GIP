<?php
    $deurnaam_cookie = $_COOKIE['deurnaam'];
    $deurrank_cookie = $_COOKIE['deurrank'];

    echo $deurnaam_cookie."<br>";
    echo $deurrank_cookie."<br>";
?>